import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * class for implementing Tries operations
 * 
 * @author G02 (Bala Chandra Yadav, Ravindhar, Mohammad Rafi)
 * 
 */
public class TriesUtil {
	Entry root;
	static final String EMPTY = "";

	/**
	 * Adds a word from the dictionary to the Tri, if it does not exist already
	 * 
	 * @param word
	 *            : String: word to be added to the Tri
	 */
	void add(String word) {
		if (!contains(word))
			root = add(word, 0, root);
	}

	/**
	 * Adds a word to the Tri and returns the newly created Entry
	 * 
	 * @param word
	 *            : String: word to be added to the Tri
	 * @param index
	 *            : int : the index of current character in the string
	 * @param node
	 *            : Entry: the entry to be created
	 * @return: Entry: returns the newly created node
	 */
	Entry add(String word, int index, Entry node) {
		// If the node is null, create a new entry
		if (node == null) {
			// If we reach the end of a word, just return
			if (index == word.length()) {
				node = new Entry(true, index, 1);
				return node;
			} else {
				node = new Entry(false, index, 0);

			}
		}
		// Increasing the frequency
		node.frequency = node.frequency + 1;
		// If we reach the end of a word, set its isDict to true
		if (index == word.length()) {
			node.isDictionary = true;
		} else {
			try {
				int pos = getIndex(word.charAt(index));
				node.children[pos] = add(word, index + 1, node.children[pos]);
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out
						.println(word
								+ " is not a valid word.Word should contain only alphabets");
			}
		}
		return node;
	}

	/**
	 * Removes a word from the Tri, if it exists already
	 * 
	 * @param word
	 *            : String: word to be removed
	 */
	void remove(String word) {
		if (EMPTY.equals(word))
			return;
		// Checking the existence of the word
		if (contains(word)) {
			int len = word.length();
			int i = 0;
			Entry cur = root;
			Entry temp = null;
			int index;

			// Loop Invariant : temp holds the reference to the Entry
			// representing the first character in the given string, in each
			// iteration it is updated to hold the reference to character at
			// i'th position in string. Using this reference, if the frequency
			// is 1 which indicates that this is the only element, the further
			// processing is halted and the reference is removed. If the
			// frequency is greater than 1, it is decremented accordingly
			while (i < len) {
				index = getIndex(word.charAt(i));
				temp = cur.children[index];
				if (temp.frequency == 1) {
					cur.children[index] = null;
					return;
				}
				temp.frequency--;
				cur = temp;
				i = i + 1;
			}
			cur.isDictionary = false;
		} else {
			System.out.println("Given word is not present in the dictionary");
		}
	}

	/**
	 * Reads the input file and adds each word to the current trie.
	 * 
	 * @param file
	 *            : String : file location
	 */
	void importFromFile(String file) {
		try {
			File stringInput = new File(file);
			Scanner in = new Scanner(stringInput);
			while (in.hasNext()) {
				add(in.next());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Returns true if the given word is present in the current trie
	 * 
	 * @param word
	 *            : String : input word
	 * @return: boolean : true if word is present in the trie, false otherwise
	 */
	boolean contains(String word) {
		Entry node = getLastNode(word);
		if (node == null)
			return false;
		return node.isDictionary;
	}

	/**
	 * Returns the count of the entries with word as prefix in the current trie
	 * 
	 * @param word
	 *            : String : input prefix
	 * @return : int : count of words with word as prefix
	 */
	int prefix(String word) {
		Entry node = getLastNode(word);
		if (node == null)
			return 0;
		return node.frequency;
	}

	/**
	 * Returns index of the character in the children array, it directly uses
	 * the character value to calculate the index
	 * 
	 * @param c
	 *            : char : input character
	 * @return : int : index
	 */
	int getIndex(char c) {
		if (c >= 97 && c <= 122)
			return c - 97;
		else if (c >= 65 && c <= 90)
			return c - 65;
		return -1;
	}

	/**
	 * Returns the entry which represents the last character in the given word,
	 * null if the word is not present
	 * 
	 * @param word
	 *            : String : input word
	 * @return : Entry : last node if present, null otherwise
	 */
	Entry getLastNode(String word) {
		if (root == null)
			return null;
		int len = word.length();
		int i = 0;
		Entry cur = root;
		Entry temp = null;

		// Loop Invariant: temp holds the reference to Entry representing each
		// character in the given word, begins with first character and proceeds
		// until the word is exhausted or it fails to find next character entry
		while (i < len) {
			try {
				int index = getIndex(word.charAt(i));
				temp = cur.children[index];
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out
						.println(word
								+ " is not a valid word. Word should contain only alphabets");
			}
			if (temp == null)
				return null;
			i = i + 1;
			cur = temp;
		}
		return cur;
	}
}
