Group: G02
Group Members : Bala Chandra Yadav (bxy140430), Ravindhar Reddy (rxt140930), Mohammad Rafi Shaik

Problems Attempted: All (1,2)

Instructions to Execute the files
1. Extract the archive and Copy all the source files to the required directory.
2. Please use below commands to compile the source files
> javac Driver.java
3. Execute the files using below commands
> java Driver [input.txt]

Description of Files
Driver.java  - Driver program for string matching.
StringMatching.java - class for string matching
BoyerMoore.java - Class for BoyerMoore ( source: wikipedia)
TriesDriver.java - Driver Program for Tries Implementation
TriesUtil.java - Class implementing tries operations
Entry.java - Class defining entry for Tri
Timer.java - Timer class
 