/**
 * class for implementing Tries Entry
 * 
 * @author G02 (Bala Chandra Yadav, Ravindhar Reddy Thallapureddy, Mohammad
 *         Rafi)
 * 
 */
public class Entry {
	boolean isDictionary;
	int depth;
	int frequency;
	Entry[] children;

	Entry() {
		isDictionary = false;
		children = new Entry[26];
		depth = 0;
		frequency = 1;
	}

	Entry(boolean isDict, int index, int freq) {
		isDictionary = isDict;
		depth = index;
		frequency = freq;
		children = new Entry[26];
	}

}
