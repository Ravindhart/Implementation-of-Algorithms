import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

/**
 * class for testing the directed graph methods like topological sorting.
 * 
 * @author G02 (Bala Chandra Yadav, Ravindhar, Mohammad Rafi)
 *
 */
public class TriesDriver {

	/**
	 * main method which reads input data from either System.in or file and
	 * prints the topological order of the graph built using the input data.
	 * 
	 * @param args
	 *            : arguments if any
	 * @throws FileNotFoundException
	 *             : Exception if the file name given is not present
	 */
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in;
		if (args.length > 0) {
			File inputFile = new File(args[0]);
			in = new Scanner(inputFile);
		} else {
			in = new Scanner(System.in);
		}

		TriesUtil newTrie = new TriesUtil();
		newTrie.add(in.next());
		newTrie.add(in.next());
		newTrie.add(in.next());
		int pCount = newTrie.prefix(in.next());
		System.out.println(pCount);
		newTrie.remove(in.next());
		if (newTrie.contains(in.next()))
			System.out.println("Entered word is present");
		else
			System.out.println("Entered word is not present");
	}
}
/*
 * sample input - algorithms algos algo algo algo algo
 */
