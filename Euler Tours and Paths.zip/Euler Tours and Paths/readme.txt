Group: G02
Group Members : Bala Chandra Yadav (bxy140430), Ravindhar Reddy (rxt140930), Mohammad Rafi Shaik

Problems Attempted: 1

Instructions to Execute the files
1. Extract the archive and Copy all the source files to the required directory.
2. Please use below commands to compile the source files
> javac Driver.java
3. Execute the files using below commands
> java Driver [input.txt]
Here input.txt is an optional input file from which the graph is read

Description of Files
Driver.java  - Driver program.
Graph.java - class which represents a graph
Edge.java - class which represents an arc/edge of a graph
Vertex.java - class which represents a vertex/node in a graph
Helper.java - helper class for Graph functions 
Index.java - Interface for Index
DoublyLinkedList - class for DoublyLinkedList DS
Entry - class for an entry in DoublyLinkedList
Timer - class for capturing times
EulerUtil - class which has methods for finding euler tours, paths
EulerBean - class which acts a simple bean used as a return type from various functions

 